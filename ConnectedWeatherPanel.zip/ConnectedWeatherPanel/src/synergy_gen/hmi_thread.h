/* generated thread header file - do not edit */
#ifndef HMI_THREAD_H_
#define HMI_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
void hmi_thread_entry(void);
#include "r_flash_hp.h"
#include "r_flash_api.h"
#include "r_dtc.h"
#include "r_transfer_api.h"
#include "r_sci_spi.h"
#include "r_spi_api.h"
#include "r_icu.h"
#include "r_external_irq_api.h"
#include "sf_external_irq.h"
#include "r_riic.h"
#include "r_i2c_api.h"
#include "sf_touch_panel_i2c.h"
#include "sf_touch_panel_api.h"
#ifdef __cplusplus
extern "C"
{
#endif
/* Flash on Flash HP Instance */
extern const flash_instance_t g_flash0;
#ifdef NULL
#define FLASH_CALLBACK_USED (0)
#else
#define FLASH_CALLBACK_USED (1)
#endif
#if FLASH_CALLBACK_USED
void NULL(flash_callback_args_t * p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer1;
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer0;
extern const spi_cfg_t g_spi_lcdc_cfg;
/** SPI on SCI Instance. */
extern const spi_instance_t g_spi_lcdc;
#ifdef g_lcd_spi_callback
#define SPI_ON_SCI_SPI_CALLBACK_USED_g_spi_lcdc (0)
#else
#define SPI_ON_SCI_SPI_CALLBACK_USED_g_spi_lcdc (1)
#endif
#if SPI_ON_SCI_SPI_CALLBACK_USED_g_spi_lcdc
void g_lcd_spi_callback(spi_callback_args_t * p_args);
#endif
/* External IRQ on ICU Instance. */
extern const external_irq_instance_t g_external_irq0;
#ifdef NULL
#define EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_external_irq0 (0)
#else
#define EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_external_irq0 (1)
#endif
#if EXTERNAL_IRQ_ON_ICU_CALLBACK_USED_g_external_irq0
void NULL(external_irq_callback_args_t * p_args);
#endif
/** SF External IRQ on SF External IRQ Instance. */
extern const sf_external_irq_instance_t g_sf_external_irq0;
extern const i2c_cfg_t g_i2c0_cfg;
/** I2C on RIIC Instance. */
extern const i2c_master_instance_t g_i2c0;
#ifdef NULL
#define I2C_CALLBACK_USED_g_i2c0 (0)
#else
#define I2C_CALLBACK_USED_g_i2c0 (1)
#endif
#if I2C_CALLBACK_USED_g_i2c0
void NULL(i2c_callback_args_t * p_args);
#endif
/** SF Touch Panel on SF Touch Panel I2C Instance. */
extern const sf_touch_panel_instance_t g_sf_touch_panel_i2c0;
/** Touch Chip Driver Instance to be attached to SF Touch Panel */
extern const sf_touch_panel_i2c_chip_t g_sf_touch_panel_i2c_chip_sx8654;
/** Messaging Framework Instance */
extern const sf_message_instance_t g_sf_message;
extern TX_QUEUE g_new_queue0;
extern TX_SEMAPHORE g_hmi_semaphore_lcdc;
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* HMI_THREAD_H_ */
