/* HMI Thread entry function */

#include "hmi_thread.h"
#include "gx_api.h"
#include "fx_api.h"
#include "nx_api.h"
#include "nx_dhcp.h"
#include "nx_http_server.h"
#include "nx_dns.h"
#if defined(BSP_BOARD_S7G2_PE_HMI1)
#include "s7g2_pe_hmi1/weather_resources.h"
#include "s7g2_pe_hmi1/weather_specifications.h"
#define DATA_FLASH_BLOCK_SIZE 64
#define DATA_FLASH_PROGRAMMING_UNIT 4
#elif defined(BSP_BOARD_S7G2_DK)
#include "s7g2_dk/weather_resources.h"
#include "s7g2_dk/weather_specifications.h"
#define DATA_FLASH_BLOCK_SIZE 64
#define DATA_FLASH_PROGRAMMING_UNIT 4
#elif defined(BSP_BOARD_S7G2_SK)
#include "s7g2_sk/weather_resources.h"
#include "s7g2_sk/weather_specifications.h"
#include "s7g2_sk/lcd.h"
#define DATA_FLASH_BLOCK_SIZE 64
#define DATA_FLASH_PROGRAMMING_UNIT 4
#endif

#include <m1_agent.h>

#include "custom_gx.h"

GX_WINDOW_ROOT * p_window_root;

#if defined(BSP_BOARD_S7G2_SK)
void g_lcd_spi_callback(spi_callback_args_t * p_args);
#endif
void hmi_thread_main(void);
static void hmi_send_touch_message(sf_touch_panel_payload_t * p_payload);

NX_PACKET_POOL  g_http_packet_pool;
       NX_IP           g_http_ip;
static NX_DHCP         g_dhcp;
NX_DNS           g_dns_client;
int splash_ended = 0;

static CHAR mem_packet_pool[(1536 + 32 + sizeof(NX_PACKET)) * 30] __attribute__ ((aligned(4)));
static CHAR mem_ip_stack[2048] __attribute__ ((aligned(4)));
static CHAR mem_arp[1024] __attribute__ ((aligned(4)));

extern VOID nx_ether_driver_eth1(NX_IP_DRIVER *);
extern const char provisionHtml[];

typedef struct st_day_info
{
    char            * day_name;
    char            * description;
    char            * humidity;
    char            * hi_temp;
    char            * lo_temp;
    GX_RESOURCE_ID  background;
    GX_RESOURCE_ID  icon;
    GX_RESOURCE_ID  animation;
    GX_RESOURCE_ID  btnicon;
} day_info_t;

extern day_info_t forecast[3];

static char day_day_key[] = "D%d_Day\": \"";
static char day_description_key[] = "D%d_Condition\": \"";
static char day_humidity_key[] = "D%d_Humidity\": ";
char day_name[3][4];
char day_description[3][50];
char day_humidity[3][4];
char day_temphi[3][4];
char day_templo[3][4];
char day_bg[3][100];
char current_city[30];
char current_state[30];
char current_location[51];

extern int hours;
extern int minutes;

UCHAR                   ram_disk_memory[13*1024];
UCHAR                   ram_disk_sector_cache[512];
FX_MEDIA                ram_disk_media;
FX_MEDIA *              gp_media;
extern VOID    _fx_ram_driver(FX_MEDIA *media_ptr);

static NX_HTTP_SERVER  g_http_server;
#define HTTP_STACK_SIZE (4 * 1024)
static CHAR mem_http_stack[HTTP_STACK_SIZE]  __attribute__ ((aligned(4)));

UINT my_get_notify(NX_HTTP_SERVER *server_ptr, UINT request_type, CHAR *resource, NX_PACKET *packet_ptr);

static int extract_string(const char * msg, const char * key, char * output) {
    char * temp = strstr(msg, key);
    if (temp != NULL) {
        temp += strlen(key);
        strncpy(output, temp, strstr(temp, "\"") - temp);
        output[strstr(temp, "\"") - temp] = '\0';
        return 0;
    }
    return -1;
}

static int extract_num(const char * msg, const char * key, char * output) {
    char * temp = strstr(msg, key);
    if (temp != NULL) {
        temp += strlen(key);
        char * end = strstr(temp, ",");
        if (end == NULL) {
            end = strstr(temp, "}");
            if (end == NULL)
                return -2;
        }
        strncpy(output, temp, end - temp);
        output[end - temp] = '\0';
        return 0;
    }
    return -1;
}

void subscription_callback(int type, char * topic, char * msg, int length) {
    char key[50];

    if (msg[0] == '{') {
        for (int i = 0; i < 3; i++) {
            sprintf(key, day_day_key, i);
            if (!extract_string(msg, key, day_name[i]))
                forecast[i].day_name = day_name[i];
            sprintf(key, day_description_key, i);
            if (!extract_string(msg, key, day_description[i]))
                forecast[i].description = day_description[i];
            sprintf(key, day_humidity_key, i);
            if (!extract_num(msg, key, day_humidity[i]))
                forecast[i].humidity = day_humidity[i];
            sprintf(key, "D%d_Temp_Hi\": ", i);
            if (!extract_num(msg, key, day_temphi[i]))
                forecast[i].hi_temp = day_temphi[i];
            sprintf(key, "D%d_Temp_Lo\": ", i);
            if (!extract_num(msg, key, day_templo[i]))
                forecast[i].lo_temp = day_templo[i];
            sprintf(key, "D%d_BG\": \"", i);
            if (!extract_string(msg, key, day_bg[i])) {
                if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_BG_SUNNY"))
                    forecast[i].background = GX_PIXELMAP_ID_BG_SUNNY;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_BG_PARTLYCLOUDY"))
                    forecast[i].background = GX_PIXELMAP_ID_BG_PARTLYCLOUDY;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_BG_RAINY"))
                    forecast[i].background = GX_PIXELMAP_ID_BG_RAINY;
            }
            sprintf(key, "D%d_ANIME_1\": \"", i);
            if (!extract_string(msg, key, day_bg[i])) {
                if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_SUN_SHINING"))
                    forecast[i].icon = GX_PIXELMAP_ID_ANIME_SUN_SHINING;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_RAINING_1"))
                    forecast[i].icon = GX_PIXELMAP_ID_ANIME_RAINING_1;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_RAINING_2"))
                    forecast[i].icon = GX_PIXELMAP_ID_ANIME_RAINING_2;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_CLOUD"))
                    forecast[i].icon = GX_PIXELMAP_ID_ANIME_CLOUD;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_SUN_SHINING"))
                    forecast[i].icon = GX_PIXELMAP_ID_ANIME_SUN_SHINING;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_SUN_ONCLOUD"))
                    forecast[i].icon = GX_PIXELMAP_ID_ANIME_SUN_ONCLOUD;
                else
                    forecast[i].icon = 0;
            }
            sprintf(key, "D%d_ANIME_2\": \"", i);
            if (!extract_string(msg, key, day_bg[i])) {
                if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_SUN_SHINING"))
                    forecast[i].animation = GX_PIXELMAP_ID_ANIME_SUN_SHINING;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_RAINING_1"))
                    forecast[i].animation = GX_PIXELMAP_ID_ANIME_RAINING_1;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_RAINING_2"))
                    forecast[i].animation = GX_PIXELMAP_ID_ANIME_RAINING_2;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_CLOUD"))
                    forecast[i].animation = GX_PIXELMAP_ID_ANIME_CLOUD;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_SUN_SHINING"))
                    forecast[i].animation = GX_PIXELMAP_ID_ANIME_SUN_SHINING;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ANIME_SUN_ONCLOUD"))
                    forecast[i].animation = GX_PIXELMAP_ID_ANIME_SUN_ONCLOUD;
                else
                    forecast[i].animation = 0;
            }
            sprintf(key, "D%d_Icon\": \"", i);
            if (!extract_string(msg, key, day_bg[i])) {
                if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ICON_CLOUDY"))
                    forecast[i].btnicon = GX_PIXELMAP_ID_ICON_CLOUDY;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ICON_RAINY"))
                    forecast[i].btnicon = GX_PIXELMAP_ID_ICON_RAINY;
                else if (!strcmp(day_bg[i], "GX_PIXELMAP_ID_ICON_SUNNY"))
                    forecast[i].btnicon = GX_PIXELMAP_ID_ICON_SUNNY;
            }
        }

        gx_prompt_text_set(&main_screen.main_screen_saturday_text, forecast[0].day_name);
        gx_prompt_text_set(&main_screen.main_screen_sunday_text, forecast[1].day_name);
        gx_prompt_text_set(&main_screen.main_screen_monday_text, forecast[2].day_name);

        gx_icon_pixelmap_set(&main_screen.main_screen_saturday_icon, forecast[0].btnicon, forecast[0].btnicon);
        gx_icon_pixelmap_set(&main_screen.main_screen_sunday_icon, forecast[1].btnicon, forecast[1].btnicon);
        gx_icon_pixelmap_set(&main_screen.main_screen_monday_icon_1, forecast[2].btnicon, forecast[2].btnicon);

        UpdateForecast();

        extract_string(msg, "City\": \"", current_city);
        extract_string(msg, "State\": \"", current_state);
        sprintf(current_location, "%s, %s", current_city, current_state);
        gx_prompt_text_set(&main_screen.main_screen_current_location, current_location);

        extract_string(msg, "Hour\": \"", day_bg[0]);
        sscanf(day_bg[0], "%d", &hours);
        extract_string(msg, "Minute\": \"", day_bg[0]);
        sscanf(day_bg[0], "%d", &minutes);
    } else {
        GX_EVENT gxe;
        int target_temp;

        sscanf(msg, "%d", &target_temp);
        gxe.gx_event_type = GX_EVENT_CLOUD;
        /** Send event to GUI */
        gxe.gx_event_sender         = GX_ID_NONE;
        gxe.gx_event_target         = 0;  /* the event to be routed to the widget that has input focus */
        gxe.gx_event_display_handle = 0;
        gxe.gx_event_payload.gx_event_intdata[0] = target_temp;
        gx_system_event_send(&gxe);
    }
}

void hmi_thread_main(void)
{
    ssp_err_t err;
    UINT      status = TX_SUCCESS;
    sf_message_header_t * p_message = NULL;
    char provisionConfigBuffer[200];
    char m1_apikey[100] = {0};
    char m1_mqtt_user_id[32] = {0};
    char m1_mqtt_project_id[32] = {0};
    char m1_password[100] = {0};

    /* Initializes GUIX. */
    status = gx_system_initialize();
    if(TX_SUCCESS != status)
    {
        while(1)
           {;}
    }

    /* Initializes GUIX drivers. */
    err = g_sf_el_gx0.p_api->open (g_sf_el_gx0.p_ctrl, g_sf_el_gx0.p_cfg);
    if(SSP_SUCCESS != err)
    {
        while(1)
            {;}
    }

    gx_studio_display_configure ( MAIN_DISPLAY,
                                  g_sf_el_gx0.p_api->setup,
                                  LANGUAGE_ENGLISH,
                                  MAIN_DISPLAY_THEME_1,
                                  &p_window_root );

    err = g_sf_el_gx0.p_api->canvasInit(g_sf_el_gx0.p_ctrl, p_window_root);
    if(SSP_SUCCESS != err)
    {
        while(1)
        {;}
    }

    /* Creates the primary screen. */
    status = gx_studio_named_widget_create("splash_screen",
                                           (GX_WIDGET *)p_window_root, GX_NULL);
    if(TX_SUCCESS != status)
    {
        while(1)
        {;}
    }

    /* Shows the root window to make it and patients screen visible. */
    status = gx_widget_show(p_window_root);
    if(TX_SUCCESS != status)
    {
        while(1)
        {;}
    }

    /* Lets GUIX run. */
    status = gx_system_start();
    if(TX_SUCCESS != status)
    {
        while(1)
        {;}
    }

#if defined(BSP_BOARD_S7G2_PE_HMI1)
    /* Controls the GPIO pin for LCD ON. */
    err = g_ioport.p_api->pinWrite(IOPORT_PORT_10_PIN_03, IOPORT_LEVEL_HIGH);
    if (err)
    {
        while(1)
        {;}
    }
#elif defined(BSP_BOARD_S7G2_DK)
    /* Controls the GPIO pin for LCD ON. */
    err = g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_10, IOPORT_LEVEL_HIGH);
    if (err)
    {
        while(1)
        {;}
    }
#elif defined(BSP_BOARD_S7G2_SK)
    /** Open the SPI driver to initialize the LCD **/
    err = g_spi_lcdc.p_api->open(g_spi_lcdc.p_ctrl, (spi_cfg_t *)g_spi_lcdc.p_cfg);

    /** Setup the ILI9341V **/
    ILI9341V_Init();
#endif

#if defined(BSP_BOARD_S7G2_PE_HMI1) || defined(BSP_BOARD_S7G2_DK)
    /* Opens PWM driver and controls the TFT panel back light. */
    err = g_pwm_backlight.p_api->open(g_pwm_backlight.p_ctrl, g_pwm_backlight.p_cfg);
    if (err)
    {
        while(1)
        {;}
    }
#endif

#define APP_ERR_TRAP(x) do {if(x)while(1);}while(0);

    // networking start
    nx_system_initialize();

    status = nx_packet_pool_create(&g_http_packet_pool, "Netx Packet Pool", (1536 + 32),
                                   mem_packet_pool, sizeof(mem_packet_pool));
    APP_ERR_TRAP(status)

    status = nx_ip_create(&g_http_ip, "IP Instance",
                          IP_ADDRESS(0,0,0,0), 0xFFFFFF00UL,
                          &g_http_packet_pool, nx_ether_driver_eth1,
                          mem_ip_stack, sizeof(mem_ip_stack), 1);
    APP_ERR_TRAP(status)

    status = nx_ip_fragment_enable(&g_http_ip);
    APP_ERR_TRAP(status)

    status = nx_arp_enable(&g_http_ip, mem_arp, sizeof(mem_arp));
    APP_ERR_TRAP(status)

    status =  nx_udp_enable(&g_http_ip);
    APP_ERR_TRAP(status)

    status = nx_tcp_enable(&g_http_ip);
    APP_ERR_TRAP(status)

    status = nx_icmp_enable(&g_http_ip);
    APP_ERR_TRAP(status)

    status = nx_dhcp_create(&g_dhcp, &g_http_ip, "Netx DHCP");
    APP_ERR_TRAP(status)

    status =  nx_dhcp_start(&g_dhcp);
    APP_ERR_TRAP(status)

    status = nx_dns_create(&g_dns_client, &g_http_ip, "Netx DNS");
    APP_ERR_TRAP(status)

    status = nx_dns_server_add(&g_dns_client, (8L << 24) + (8L << 16) + (8L << 8) + 8L);
    APP_ERR_TRAP(status)

    ULONG dhcp_status = 0;

    while (dhcp_status != NX_IP_ADDRESS_RESOLVED)
    {
        status = nx_ip_status_check(&g_http_ip, NX_IP_ADDRESS_RESOLVED, &dhcp_status, 100);
    }

    int actual_size;
    status = g_flash0.p_api->open(g_flash0.p_ctrl, g_flash0.p_cfg);
    APP_ERR_TRAP(status)
    status = g_flash0.p_api->read(g_flash0.p_ctrl, provisionConfigBuffer, 0x40100000, sizeof(provisionConfigBuffer) - 1);
    APP_ERR_TRAP(status)
    status = g_flash0.p_api->close(g_flash0.p_ctrl);
    APP_ERR_TRAP(status)
    actual_size = strnlen(provisionConfigBuffer, sizeof(provisionConfigBuffer) - 1);
    provisionConfigBuffer[actual_size] = '\0';
    char * temp, * dst, * delimiter;
    temp = provisionConfigBuffer;
    for (int i = 0; i < 4; i++) {
        if (!strncmp(temp, "apikey", 6))
            dst = m1_apikey;
        else if (!strncmp(temp, "mqttuserid", 10))
            dst = m1_mqtt_user_id;
        else if (!strncmp(temp, "mqttprojectid", 13))
            dst = m1_mqtt_project_id;
        else if (!strncmp(temp, "password", 8))
            dst = m1_password;
        else
            continue;
        temp = strchr(temp, '=') + 1;
        delimiter = strchr(temp, '&');
        if (delimiter == NULL)
            delimiter = strchr(temp, '\0');
        memcpy(dst, temp, delimiter - temp);
        dst[delimiter - temp] = '\0';
        temp = delimiter + 1;
    }

    /* Format the RAM disk - the memory for the RAM disk was defined above.  */
    status = fx_media_format(&ram_disk_media,
                          _fx_ram_driver,                  /* Driver entry             */
                          ram_disk_memory,                 /* RAM disk memory pointer  */
                          ram_disk_sector_cache,           /* Media buffer pointer     */
                          sizeof(ram_disk_sector_cache),   /* Media buffer size        */
                          (CHAR*)"MY_RAM_DISK",            /* Volume Name              */
                          1,                               /* Number of FATs           */
                          32,                              /* Directory Entries        */
                          0,                               /* Hidden sectors           */
                          sizeof(ram_disk_memory) / sizeof(ram_disk_sector_cache),/* Total sectors            */
                          sizeof(ram_disk_sector_cache),   /* Sector size              */
                          1,                               /* Sectors per cluster      */
                          1,                               /* Heads                    */
                          1);                              /* Sectors per track        */
    APP_ERR_TRAP(status)

    /* Open the RAM disk.  */
    status = fx_media_open(&ram_disk_media, (CHAR*)"RAM DISK", _fx_ram_driver, ram_disk_memory, ram_disk_sector_cache, sizeof(ram_disk_sector_cache));
    APP_ERR_TRAP(status)
    gp_media = &ram_disk_media;
    FX_FILE my_file;
    status = fx_file_create(gp_media, "index.html");
    APP_ERR_TRAP(status)
    status = fx_file_open(gp_media, &my_file, "index.html", FX_OPEN_FOR_WRITE);
    APP_ERR_TRAP(status)
    status = fx_file_write(&my_file, provisionHtml, strlen(provisionHtml));
    APP_ERR_TRAP(status)
    status = fx_file_close(&my_file);
    APP_ERR_TRAP(status)

    status = nx_http_server_create(&g_http_server, "HTTP Server Instance", &g_http_ip,
                                   gp_media, mem_http_stack, sizeof(mem_http_stack),
                                   &g_http_packet_pool, NX_NULL, &my_get_notify);
    APP_ERR_TRAP(status)

    status = nx_http_server_start(&g_http_server);
    APP_ERR_TRAP(status)

    while (!splash_ended) {
        tx_thread_sleep(10);
    }
    // display the IP address
    ULONG ip_address, ip_mask;
    nx_ip_address_get(&g_http_ip, &ip_address, &ip_mask);

    GX_EVENT gxe;

    gxe.gx_event_type = GX_EVENT_IPADDRESS;
    /** Send event to GUI */
    gxe.gx_event_sender         = GX_ID_NONE;
    gxe.gx_event_target         = 0;  /* the event to be routed to the widget that has input focus */
    gxe.gx_event_display_handle = 0;
    gxe.gx_event_payload.gx_event_ulongdata = ip_address;
    gx_system_event_send(&gxe);

    // check to see if m1 credentials look valid.
    if (strlen(m1_mqtt_project_id)) {
        // register callback for m1 published messages
        m1_register_subscription_callback(subscription_callback);

        m1_connect("mqtt2.mediumone.com",
            61620,
            m1_mqtt_user_id,
            m1_password,
            m1_mqtt_project_id,
            m1_apikey,
            "sk-s7g2",
            5, 5, 30, 1);
    }

    while (1)
    {
        g_sf_message.p_api->pend(g_sf_message.p_ctrl, &hmi_thread_message_queue, (sf_message_header_t **) &p_message, TX_WAIT_FOREVER);
        switch (p_message->event_b.class)
        {
        case SF_MESSAGE_EVENT_CLASS_TOUCH:
            if (SF_MESSAGE_EVENT_NEW_DATA == p_message->event_b.code)
            {
                sf_touch_panel_payload_t * p_touch_message = (sf_touch_panel_payload_t *) p_message;

                /** Translate a touch event into a GUIX event */
                hmi_send_touch_message(p_touch_message);
            }
            break;
        default:
            break;
        }

        /** Message is processed, so release buffer. */
        err = g_sf_message.p_api->bufferRelease(g_sf_message.p_ctrl, (sf_message_header_t *) p_message, SF_MESSAGE_RELEASE_OPTION_NONE);
        if (err)
        {
            while(1)
            {;}
        }
    }
}

/*******************************************************************************************************************//**
 * @brief  Sends a touch event to GUIX internal thread to call the GUIX event handler function
 *
 * @param[in] p_payload Touch panel message payload
***********************************************************************************************************************/
static void hmi_send_touch_message(sf_touch_panel_payload_t * p_payload)
{
    bool send_event = true;
    GX_EVENT gxe;

    switch (p_payload->event_type)
    {
    case SF_TOUCH_PANEL_EVENT_DOWN:
        gxe.gx_event_type = GX_EVENT_PEN_DOWN;
        break;
    case SF_TOUCH_PANEL_EVENT_UP:
        gxe.gx_event_type = GX_EVENT_PEN_UP;
        break;
    case SF_TOUCH_PANEL_EVENT_HOLD:
    case SF_TOUCH_PANEL_EVENT_MOVE:
        gxe.gx_event_type = GX_EVENT_PEN_DRAG;
        break;
    case SF_TOUCH_PANEL_EVENT_INVALID:
        send_event = false;
        break;
    default:
        break;
    }

    if (send_event)
    {
        /** Send event to GUI */
        gxe.gx_event_sender         = GX_ID_NONE;
        gxe.gx_event_target         = 0;  /* the event to be routed to the widget that has input focus */
        gxe.gx_event_display_handle = 0;

        gxe.gx_event_payload.gx_event_pointdata.gx_point_x = p_payload->x;
#if defined(BSP_BOARD_S7G2_SK)
        gxe.gx_event_payload.gx_event_pointdata.gx_point_y = (GX_VALUE)(320 - p_payload->y);
#else
        gxe.gx_event_payload.gx_event_pointdata.gx_point_y = p_payload->y;
#endif

        gx_system_event_send(&gxe);
    }
}

#if defined(BSP_BOARD_S7G2_SK)
void g_lcd_spi_callback(spi_callback_args_t * p_args)
{
    if (p_args->event == SPI_EVENT_TRANSFER_COMPLETE)
        tx_semaphore_ceiling_put(&g_hmi_semaphore_lcdc, 1);

}
#endif


UINT my_get_notify(NX_HTTP_SERVER *server_ptr, UINT request_type, CHAR *resource, NX_PACKET *packet_ptr)
{
    ssp_err_t ssp_err;
    int status;
    UINT length;
    NX_PACKET *response_pkt;
    UCHAR provisionConfigBuffer[300];

    /* Look for the test resource! */
    if ((request_type == NX_HTTP_SERVER_GET_REQUEST) && (strcmp(resource, "/") == 0)) {
        strcat(resource, "index.html");
    } else if(request_type == NX_HTTP_SERVER_POST_REQUEST) { /* Process multipart data. */
#if 0 // the entity stuff isn't working
        /* Get the content header. */
        while(nx_http_server_get_entity_header(server_ptr, &packet_ptr, provisionConfigBuffer, sizeof(provisionConfigBuffer)) == NX_SUCCESS) {
            /* Header obtained successfully. Get the content data location. */
            while(nx_http_server_get_entity_content(server_ptr, &packet_ptr, &offset, &length) == NX_SUCCESS) {
                /* Write content data to buffer. */
                nx_packet_data_extract_offset(packet_ptr, offset, provisionConfigBuffer, length, &length);
                provisionConfigBuffer[length] = 0;
            }
        }
#else
        status = nx_http_server_content_get(server_ptr, packet_ptr, 0, provisionConfigBuffer, sizeof(provisionConfigBuffer) - 1, &length);
#endif
        if (length >= sizeof(provisionConfigBuffer)) {
            // TODO: return error to user
        }
        provisionConfigBuffer[length] = '\0';
        UCHAR * urldecode = strchr(provisionConfigBuffer, '%');
        while (urldecode != NULL) {
            status = sscanf(&urldecode[1], "%2hhx", urldecode);
            if (status != 1) {
                // TODO: return error to user
            }
            memcpy(&urldecode[1], &urldecode[3], length - (urldecode - provisionConfigBuffer));
            urldecode = strchr(&urldecode[1], '%');
        }
#ifdef USB_PROVISION
        status = fx_file_open(gp_media, &my_file, "m1.txt", FX_OPEN_FOR_WRITE);
        if (status == FX_NOT_FOUND) {
            status = fx_file_create(gp_media, "m1.txt");
            if (status != FX_SUCCESS)
                while (1);
            status = fx_file_open(gp_media, &my_file, "m1.txt", FX_OPEN_FOR_WRITE);
        }
        if (status != FX_SUCCESS) {
            while (1);
        }
        status = fx_file_truncate(&my_file, 0);
        if (status != FX_SUCCESS) {
            while (1);
        }
        status = fx_file_write(&my_file, provisionConfigBuffer, length);
        if (status != FX_SUCCESS) {
            while (1);
        }
        status = fx_file_close(&my_file);
        if (status != FX_SUCCESS) {
            while (1);
        }
        status = fx_media_close(gp_media);
        if (status != FX_SUCCESS) {
            while (1);
        }
#else
        ssp_err = g_flash0.p_api->open(g_flash0.p_ctrl, g_flash0.p_cfg);
        APP_ERR_TRAP(ssp_err)
        // TODO: verify we have enough space in flash...
        int blocks = 0;
        int temp_length = length + 1;
        while (temp_length > 0) {
            blocks++;
            temp_length -= DATA_FLASH_BLOCK_SIZE;
        }
        ssp_err = g_flash0.p_api->erase(g_flash0.p_ctrl, 0x40100000, blocks);
        APP_ERR_TRAP(ssp_err)
        ssp_err = g_flash0.p_api->write(g_flash0.p_ctrl, (uint32_t)provisionConfigBuffer, 0x40100000,
                                        ((length + 1) + DATA_FLASH_PROGRAMMING_UNIT - 1) & ~(DATA_FLASH_PROGRAMMING_UNIT - 1));
        APP_ERR_TRAP(ssp_err)
        ssp_err = g_flash0.p_api->close(g_flash0.p_ctrl);
        APP_ERR_TRAP(ssp_err)
#endif

        // TODO: this response is apparently incomplete
        /* Generate HTTP header. */
        if (length == sizeof(provisionConfigBuffer))
            status = nx_http_server_callback_generate_response_header(server_ptr, &response_pkt, NX_HTTP_STATUS_OK, 800, "text/html", "Payload too large. Server: NetX HTTP 5.3\r\n");
        else
            status = nx_http_server_callback_generate_response_header(server_ptr, &response_pkt, NX_HTTP_STATUS_OK, 800, "text/html", "Server: NetX HTTP 5.3\r\n");
        if (status == NX_SUCCESS) {
            if (nx_http_server_callback_packet_send(server_ptr, response_pkt) != NX_SUCCESS) {
                nx_packet_release(response_pkt);
            }
        }
        /* Release the received client packet.      */
        nx_packet_release(packet_ptr);

        /* Indicate the response to client is transmitted. */
        return(NX_HTTP_CALLBACK_COMPLETED);
    }

    /* Indicate we have not processed the response to client yet.*/
    return NX_SUCCESS;
}
