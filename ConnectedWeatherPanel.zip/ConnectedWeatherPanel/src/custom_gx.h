/*
 * custom_gx.h
 *
 *  Created on: Sep 30, 2016
 *      Author: demo
 */

#ifndef CUSTOM_GX_H_
#define CUSTOM_GX_H_


#define GX_EVENT_CLOUD      1000
#define GX_EVENT_IPADDRESS  1001

#endif /* CUSTOM_GX_H_ */
